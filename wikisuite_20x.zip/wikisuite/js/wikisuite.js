(function($) {
    $('.dropdown .separator a').click(function() { return false; });
    $('.header_outer .settings a').click(function() {
        $('.header_outer .box-search > div > form').hide();
        $('.header_outer div[id*="mod-login_box"]').hide();
        $('.searchbutton').removeClass('open');
        $('.profilebutton').removeClass('open');
    });

    $('.header_outer .box-search').prepend('<a class="searchbutton fa fa-search"></a>');
    $('.header_outer .box-login_box').prepend('<a class="profilebutton fa fa-user"></a>');
    $('.header_outer .box-login_box button').prepend('<span class="fa fa-user"></span>');
    $('.header_outer .box-search .btn-group').addClass('fa fa-search');
    $('.header_outer .box-search > div > form').hide();
    $('.header_outer div[id*="mod-login_box"]').hide();

    $('.searchbutton').click(function() {
        $('.header_outer div[id*="mod-login_box"]').hide();
        $('.profilebutton').removeClass('open');
        $('.header_outer .box-search > div > form').toggle();
        if ( $('.searchbutton').hasClass('open') ) { $('.searchbutton').removeClass('open'); }
        else { $('.searchbutton').addClass('open'); }
    });

    $('.profilebutton').click(function() {
        $('.header_outer .box-search > div > form').hide();
        $('.searchbutton').removeClass('open');
        $('.header_outer div[id*="mod-login_box"]').toggle();
        if ( $('.profilebutton').hasClass('open') ) { $('.profilebutton').removeClass('open'); }
        else { $('.profilebutton').addClass('open'); }
    });

    $('.home-blog article').click(function() {
        window.location.href = $(this).find('.blog-postbody-title a').attr('href');
    });
})(jQuery);

$(document).ready(function(){
    var offset = $(':target').offset();
    var scrollto = offset.top - 90;
    $('html, body').animate({ scrollTop: scrollto }, 0);
});

key('left', function() {
    if ( $('.tiki-pagehistory .prevnext.prev').length ) {
        window.location.href = $('.tiki-pagehistory .prevnext.prev').attr('href');
    }
});
key('right', function() {
    if ( $('.tiki-pagehistory .prevnext.next').length ) {
        window.location.href = $('.tiki-pagehistory .prevnext.next').attr('href');
    }
});
